/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"TOLL_BUSINESS_APP/TOLLBUSINESS/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});