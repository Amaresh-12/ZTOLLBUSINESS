sap.ui.define([
	"TOLL_BUSINESS_APP/TOLLBUSINESS/test/unit/controller/View1.controller"
], function () {
	"use strict";
});