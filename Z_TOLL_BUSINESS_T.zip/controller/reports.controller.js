sap.ui.define(["sap/ui/core/mvc/Controller"], function (t) {
	"use strict";
	return t.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.controller.reports", {
		onInit: function () {
			var t = jQuery.sap.getModulePath("TOLL_BUSINESS_APP.TOLLBUSINESS");
			var a = new sap.ui.model.json.JSONModel({
				path: t
			});
			this.getView().setModel(a, "imageModel1");
		},
		onBackreport: function (t) {
			var a = sap.ui.core.UIComponent.getRouterFor(this);
			a.navTo("TargetView1");
		},
		onPress: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "PurchaseOrder",
					action: "manage"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			});
		},
		on: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "Material",
					action: "displayOverdueStockInTransit"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			});
		},
		mon: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "PurchaseOrderItem",
					action: "monitorPurDocItems"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			});
		},
		stock: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "Material",
					action: "displayStockMultipleMaterials"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			});
		},
		DS: function (t) {
			window.open(
				"https://tws4app.techwave.net:8001/iwb?sap-client=500&sap-language=EN#Material-displayStockInTransitInWebGUI?sap-ui-tech-hint=GUI"
			);
		},
		BM: function (t) {
			window.open("https://tws4app.techwave.net:8001/iwb#BillOfMaterial-display?sap-ui-tech-hint=GUI")
		},
		onCostReport: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "ZPO_PARENT_CHILD",
					action: "manage"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			})
		},
		onPOAGReport: function (t) {
			window.open(
				"https://tws4app.techwave.net:8001/iwb#Material_Supplier_Percent-analyze?EvaluationId=E.1580380222630&/sap-iapp-state=ASQDNJ8ZH0B2QN0KXHN4611VDMRVEKOZF8CGINXB"
			)
		},
		onPressSA: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "ZASN_GR_REPORT",
					action: "display"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			})
		},
		ongoods: function (t) {
			window.open(
				"https://tws4app.techwave.net:8001/iwb?#Material_Supplier-analyze?EvaluationId=E.1578991957300&/sap-iapp-state=ASBFJN6E0H8QV0DWYZYAURJPTM9B5YSADXBGHE6D"
			)
		},
		invent: function (t) {
			var a = sap.ushell.Container.getService("CrossApplicationNavigation");
			var e = a && a.hrefForExternal({
				target: {
					semanticObject: "InventoryManagement",
					action: "displayAnalyticsOverviewPage"
				}
			});
			a.toExternal({
				target: {
					shellHash: e
				}
			})
		},
		material: function (t) {
			window.open(
				"https://tws4app.techwave.net:8001/iwb?sap-client=500&sap-language=EN#Material_Supplier_InFull-analyze?EvaluationId=E.1580453890518&/sap-iapp-state=AS1TK5ROCIGAL03P895VZ6X5Y2C0JWASNVD4DIM9"
			)
		}
	})
});