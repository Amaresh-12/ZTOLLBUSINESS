sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (Controller, Filter, FilterOperator, JSONModel) {
	"use strict";
	var currentdate = new Date();
	var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
		pattern: "dd-MMM-yyyy"
	});
	return Controller.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.controller.iwb", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf TOLL_BUSINESS_APP.TOLLBUSINESS.view.iwb
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("iwb").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function () {

			// // // //   for date logic
			//   if(vendor !="" && plant == "" && date == "")          // only vendor selected
			// {
			// var entitytable = "iwb_monitorSet?$filter=(VendorName eq " + "'" + vendor + "'" + " )";
			// }
			// else if(vendor == "" && plant != "" && date == "")    // plant is select and vendor is not select shows only plant data
			// {
			// entitytable   = "iwb_monitorSet?$filter=(Plant eq " + "'" + plant + "'" + " )";
			// }
			// else if(vendor == "" && plant == "" && date != "")    // date is select and vendor&plant is not select
			// {
			// entitytable   = "iwb_monitorSet?$filter=(CreatedDate eq datetime" + "'" + date + "'" + " )";
			// }
			// else if(vendor == "" && plant == "" && date == "" )     // vendor and plant both are not selected display the table data
			// {
			// entitytable   = "/iwb_monitorSet";
			// }
			// else if (vendor != "" && plant != "")
			// {
			// entitytable = "iwb_monitorSet?$filter=(VendorName eq '" + vendor + "' and Plant eq '" + plant + "')"; // both selected	
			// }

			// 	oDatamodelSer.read(entitytable,null,null,false,
			// 	function(table){
			// 	TableMonitor = table;
			// 	});
			// 	Jsonmode.setData(TableMonitor);
			// 	this.getView().byId("idiwb").setModel(Jsonmode);
			// }

			// 	});

			// });
			var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			//        debugger; 
			var oData = new sap.ui.model.odata.ODataModel(URL, false);
			var date = [];
			var oDataModel4 = new sap.ui.model.json.JSONModel();
			var entity = "/iwb_monitorSet";
			// var array = [];
			// var object = {};
			// var objec14t = {};
			oData.read(entity, null, null, false,
				function (Data14) {
					date = Data14;
				});
			var datechange = {};

			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd-MMM-yyyy"
			});
			for (var i = 0; i < date.results.length; i++) {
				var curdate = new Date(date.results[i].CreatedDate);
				datechange = oDateFormat.format(curdate);
				date.results[i].CreatedDate = datechange;
				datechange = {};
			}
			// date.results = array;
			oDataModel4.setData(date);
			this.getView().byId("idiwb").setModel(oDataModel4);

			// vendor dropdown
			var VendoroData = new sap.ui.model.odata.ODataModel(URL, false);
			var vendordetails = [];
			var Vendorjson = new sap.ui.model.json.JSONModel();
			
			var Vendorentity = "/vendor_infoSet";
			VendoroData.read(Vendorentity, null, null, false,
				function (Data) {
					vendordetails = Data;

				});
			Vendorjson.setData(vendordetails);
			this.getView().byId("vendorid1").setModel(Vendorjson);

			//plant drop down

			var plantoData = new sap.ui.model.odata.ODataModel(URL, false);
			var plantdetails = [];
			var plantjson = new sap.ui.model.json.JSONModel();
			var plantentity = "/PlantInfoSet";
			plantoData.read(plantentity, null, null, false,
				function (Data1) {
					plantdetails = Data1;

				});
			plantjson.setData(plantdetails);
			this.getView().byId("plantid7").setModel(plantjson);

		},

		onBack: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//	var oModel = sap.ui.getCore().getModel("Globalmodel");
			oRouter.navTo("TargetView1");
		},
		OnDate: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("idiwb");
			var sValue = oEvent.getParameter("value");
			var oBinding = oTable.getBinding("rows");
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("CreatedDate", sap.ui.model.FilterOperator.Contains, sValue)]
			});

			oBinding.filter([oFilter]);
		},
		onSearch: function (oEvent) {

			// 	var vendor = this.getView().byId("vendorid1").getValue();
			// 	var plant  = this.getView().byId("plantid7").getValue();
			// //	var date = this.getView().byId("id_date").getValue();
			// 	var Service = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			// 	var oDatamodelSer = new sap.ui.model.odata.ODataModel(Service, false);
			// 	var TableMonitor = [];
			// 	var Jsonmode = new sap.ui.model.json.JSONModel();
			// 	//
			// 			if(vendor !="" && plant == "")          // only vendor selected
			// 			{
			// 			var entitytable = "iwb_monitorSet?$filter=(VendorName eq " + "'" + vendor + "'" + " )";
			// 			}
			// 			else if(vendor == "" && plant != "")    // plant is select and vendor is not select shows only plant data
			// 			{
			// 			entitytable   = "iwb_monitorSet?$filter=(Plant eq " + "'" + plant + "'" + " )";
			// 			}
			// 			else if(vendor == "" && plant == "")     // vendor and plant both are not selected display the table data
			// 			{
			// 			entitytable   = "/iwb_monitorSet";
			// 			}
			// 			else if (vendor != "" && plant != "")
			// 			{
			// 			entitytable = "iwb_monitorSet?$filter=(VendorName eq '" + vendor + "' and Plant eq '" + plant + "')"; // both selected	
			// 			}

			// 	oDatamodelSer.read(entitytable,null,null,false,
			// 	function(table){
			// 	TableMonitor = table;
			// 	});
			// 		var datechange = {};

			// 				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			// 				pattern: "dd-MMM-yyyy"
			// 			});
			// 				for (var i = 0; i <TableMonitor .results.length; i++) {
			// 				var curdate = new Date(TableMonitor.results[i].CreatedDate);
			// 				datechange = oDateFormat.format(curdate);
			// 				TableMonitor.results[i].CreatedDate = datechange;
			// 				datechange = {};
			// 				}	 
			// 	Jsonmode.setData(TableMonitor);
			// 	this.getView().byId("idiwb").setModel(Jsonmode);
			// }
			var vendor = this.getView().byId("vendorid1").getValue();
			var plant = this.getView().byId("plantid7").getValue();
			//	var date = this.getView().byId("id_date").getValue();
			var Service = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			var oDatamodelSer = new sap.ui.model.odata.ODataModel(Service, false);
			var TableMonitor = [];
			var Jsonmode = new sap.ui.model.json.JSONModel();
			//
			if (vendor != "" && plant == "") // only vendor selected
			{
				var entitytable = "iwb_monitorSet?$filter=(VendorName eq " + "'" + vendor + "'" + " )";
			} else if (vendor == "" && plant != "") // plant is select and vendor is not select shows only plant data
			{
				entitytable = "iwb_monitorSet?$filter=(Plant eq " + "'" + plant + "'" + " )";
			} else if (vendor == "" && plant == "") // vendor and plant both are not selected display the table data
			{
				entitytable = "/iwb_monitorSet";
			} else if (vendor != "" && plant != "") {
				entitytable = "iwb_monitorSet?$filter=(VendorName eq '" + vendor + "' and Plant eq '" + plant + "')"; // both selected	
			}

			oDatamodelSer.read(entitytable, null, null, false,
				function (table) {
					TableMonitor = table;
				});
			var datechange = {};

			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd-MMM-yyyy"
			});
			for (var i = 0; i < TableMonitor.results.length; i++) {
				var curdate = new Date(TableMonitor.results[i].CreatedDate);
				datechange = oDateFormat.format(curdate);
				TableMonitor.results[i].CreatedDate = datechange;
				datechange = {};
			}
			Jsonmode.setData(TableMonitor);
			this.getView().byId("idiwb").setModel(Jsonmode);
		}

	});

});