sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.controller.reports", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf TOLL_BUSINESS_APP.TOLLBUSINESS.view.reports
		 */
		onInit: function () {
var oRootPath = jQuery.sap.getModulePath("TOLL_BUSINESS_APP.TOLLBUSINESS");
		
		var oImageModel1 = new sap.ui.model.json.JSONModel({
			path : oRootPath,
		});
		
		this.getView().setModel(oImageModel1, "imageModel1");
		},

	onBackreport: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//	var oModel = sap.ui.getCore().getModel("Globalmodel");
			oRouter.navTo("TargetView1");
		},
  onPress:function (oEvent) {
  	
  var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "PurchaseOrder",
  action: "manage"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  on : function(oEvent){
  	var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "Material",
  action: "displayOverdueStockInTransit"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  mon :function(oEvent){
  var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "PurchaseOrderItem",
  action: "monitorPurDocItems"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  stock: function(oEvent){
  var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "Material",
  action: "displayStockMultipleMaterials"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  DS:function(oEvent){
  	window.open("https://tws4app.techwave.net:8001/iwb?sap-client=500&sap-language=EN#Material-displayStockInTransitInWebGUI?sap-ui-tech-hint=GUI");
  },
  BM:function(oEvent){
  	window.open("https://tws4app.techwave.net:8001/iwb#BillOfMaterial-display?sap-ui-tech-hint=GUI");
  },
  onCostReport:function(oEvent){
   var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "ZPO_PARENT_CHILD",
  action: "manage"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  onPOAGReport:function(oEvent){
  	window.open("https://tws4app.techwave.net:8001/iwb#Material_Supplier_Percent-analyze?EvaluationId=E.1580380222630&/sap-iapp-state=ASQDNJ8ZH0B2QN0KXHN4611VDMRVEKOZF8CGINXB");
  },
  onPressSA:function(oEvent){
  	 var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "ZASN_GR_REPORT",
  action: "display"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  ongoods:function(oEvent){
  	window.open("https://tws4app.techwave.net:8001/iwb?#Material_Supplier-analyze?EvaluationId=E.1578991957300&/sap-iapp-state=ASBFJN6E0H8QV0DWYZYAURJPTM9B5YSADXBGHE6D");
  },
  invent:function(oEvent){
  	 var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "InventoryManagement",
  action: "displayAnalyticsOverviewPage"
  }
 
  })); // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
  material        :function(oEvent){
  	window.open("https://tws4app.techwave.net:8001/iwb?sap-client=500&sap-language=EN#Material_Supplier_InFull-analyze?EvaluationId=E.1580453890518&/sap-iapp-state=AS1TK5ROCIGAL03P895VZ6X5Y2C0JWASNVD4DIM9");
  }
  
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf troll.ztbp.view.reports
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf troll.ztbp.view.reports
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf troll.ztbp.view.reports
		 */
		//	onExit: function() {
		//
		//	}

	});

});