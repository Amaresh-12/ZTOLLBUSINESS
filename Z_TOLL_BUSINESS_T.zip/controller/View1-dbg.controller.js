sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";

	return Controller.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.controller.View1", {
		onInit: function () {
		var oRootPath = jQuery.sap.getModulePath("TOLL_BUSINESS_APP.TOLLBUSINESS");
		
		var oImageModel = new sap.ui.model.json.JSONModel({
			path : oRootPath,
		});
		
		this.getView().setModel(oImageModel, "imageModel");
		},
		onUserNamePress:  function(oEvent) {
		// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// //	var oModel = sap.ui.getCore().getModel("Globalmodel");
		// 	oRouter.navTo("login");
		
		},
		MPpress : function() {
  	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		
			oRouter.navTo("iwb");
    },
    onpress : function() {
//window.open("http://tws4app.techwave.net:50100/sap/bc/gui/sap/its/webgui?sap-client=500");
 // this._Dialog.destroy();
 	// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		
		// 	oRouter.navTo("erptoll");
		
  	window.open("sftp://ec2-user@13.232.111.27/Inbound_TBP_PO/");
  },
  
   DCRpress: function() {
var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		//	var oModel = sap.ui.getCore().getModel("Globalmodel");
			oRouter.navTo("reports");
    },
 adminpress: function() {
window.open("http://tws4app.techwave.net:50100/sap/bc/gui/sap/its/webgui?sap-client=500");
    },
    exppress:  function(oEvent) {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		//	var oModel = sap.ui.getCore().getModel("Globalmodel");
			oRouter.navTo("portal");
  }
	});
});