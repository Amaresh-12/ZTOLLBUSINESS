sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"TOLL_BUSINESS_APP/TOLLBUSINESS/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// // call the base component's init function
			// UIComponent.prototype.init.apply(this, arguments);

			// // enable routing
			// this.getRouter().initialize();

			// // set the device model
			// this.setModel(models.createDeviceModel(), "device");
			
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			
			jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
			jQuery.sap.require("sap.ui.core.routing.HashChanger");

			// sap.ui.core.UIComponent.prototype.init.apply(this,arguments);

			this._router = this.getRouter();

			this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);

			this._router.initialize();
			// sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
		}
	});
});