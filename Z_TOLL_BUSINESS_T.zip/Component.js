sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "TOLL_BUSINESS_APP/TOLLBUSINESS/model/models"], function (e, t, i) {
	"use strict";
	return e.extend("TOLL_BUSINESS_APP.TOLLBUSINESS.Component", {
		metadata: {
			manifest: "json"
		},
		init: function () {
			e.prototype.init.apply(this, arguments);
			this.setModel(i.createDeviceModel(), "device");
			jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
			jQuery.sap.require("sap.ui.core.routing.HashChanger");
			this._router = this.getRouter();
			this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);
			this._router.initialize();
		}
	});
});